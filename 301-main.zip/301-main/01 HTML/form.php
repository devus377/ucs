<?php
// файл для обработки формы

// form.php ? 
// first-name=Иван &
// last-name=Иванов &
// email=test%40test.ru &
// password=sdfsdlokfhls

// form.php ?
// last-name=Иванов &
// email=test%40test.ru &
// password=sdfsdfsdg