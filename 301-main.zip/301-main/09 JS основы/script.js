// объявляю переменные
// let age = 22;
// let firstName = 'Иван';
// let lastName = 'Иванов';

// console.log(firstName, lastName, age);

// let cats = 5;
// let dogs = 8;
// console.log(cats + dogs);

/**
 * многострочный комментарий
 * 
 */

// let userName = 'Vasya123';
// let head1 = document.querySelector('#head-1');
// head1.textContent = userName;

//1
// let valName_1 = 'Петя';
// let valName_2 = 'Вася';
// let valName_3 = 'Вера';
// console.log(valName_1 + valName_2 + valName_3);

//2
// let firstName = 'Igor';
// let lastName = 'Pronkin';
// let age = 34;
// let number = '8-916-341-38-35';
// let city = 'Moscow';
// let street = 'Chertanovskaya';

// console.log(firstName, lastName, age, number, city, street);

//3
// let name = 'Иван';
// let pen = 3;
// let copybook = 4;
// console.log (name, pen+copybook, 'предметов')

//4
// let a, b, c;
// a = 5;
// b = 7;
// c = 8;

// console.log('Переменная а = ' + a +'. Переменная b равна ' + b + '. Переменная c равна ' +c );
// alert ('Переменная а = ' + a +'. Переменная b равна ' + b + '. Переменная c равна ' +c)

// let cats = 5;
// let dogs = 8;

// let animals = cats + dogs;// 13

// console.log(animals);
// console.log(animals);

/*
let cartItems = 7;
// cartItems = cartItems + 2;
// cartItems += 2;

cartItems = cartItems + 1;
cartItems += 1;
cartItems++;// инкремент
cartItems--;// декремент

console.log(cartItems);*/

// const userName = 'Ivan999';
// userName = 'Itina111';

// let age = 33;
// console.log(typeof age);

// строки
// let firstName = 'Igor';
// let lastName = 'Pronkin';
// let age = 34;
// let number = '8-916-341-38-35';
// let city = 'Moscow';
// let street = 'Chertanovskaya';

// let output = '<p>Имя: firstName</p>';
// let output = "<p>Имя: firstName</p>";

// let output = '<p>Имя: ' + firstName + '</p>';
// let output = `<div class="user">
//                 <p>Имя: ${firstName}</p>
//                 <p>Фамилия: ${lastName}</p>
//               </div>`;

// console.log(output);
// document.write(output);


let carModel = '2101';
let carMaker = 'VAZ';
let madeYear = 1990;

//1
// let output = `${carModel},${carMaker},${madeYear} `;
// console.log(output);

//2
// let output = `<div class="cars">
// <p>Модельный ряд: ${carModel}</p>
// <p>Марка: ${carMaker}</p>
// <p>Год выпуска: ${madeYear}</p>
// </div>`;

// console.log(output);
// document.write(output);

//3
// let txt = `<div class="avto">
// <p>Представляем модельный ряд ${carModel}</p>
// <p>Модель ${carMaker}</p>
// <p>год выпуска ${madeYear}</p>

// </div>`;

// console.log(txt);
// document.write(txt);

// let a, b, c;
// console.log(a, b, c);
// a = 1;
// console.log(a);


// const a, b, c;
// console.log(a, b, c);